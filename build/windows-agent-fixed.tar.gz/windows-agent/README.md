# RDP Relay Windows Agent Installation

## Prerequisites
- Windows 10/11 or Windows Server 2019+
- Administrator privileges
- Network access to RDP Relay server

## Installation Steps

### Method 1: Using PowerShell (Recommended)
1. Open PowerShell as Administrator
2. Navigate to this folder
3. Run: `.\Install-RdpAgent.ps1 -ProvisioningToken "YOUR_TOKEN_HERE"`

### Method 2: Using Batch File
1. Right-click `install.bat` and select "Run as administrator"
2. Enter your provisioning token when prompted

## Getting a Provisioning Token
1. Access the RDP Relay web portal: http://159.89.112.134:8080
2. Login with your credentials
3. Go to the **Agents** page
4. Click **"Generate Token"**
5. Copy the generated token

## Verification
After installation, verify the agent is working:

1. **Check Service Status:**
   ```powershell
   Get-Service RdpRelayAgent
   ```

2. **View Logs:**
   ```powershell
   Get-Content "C:\Program Files\RdpRelay\Agent\logs\*.log" -Tail 20
   ```

3. **Check Web Portal:**
   - The agent should appear as "Online" in the web portal
   - Status updates every 30 seconds

## Troubleshooting

### Agent Shows as Offline
- Check Windows Firewall settings
- Verify network connectivity to 159.89.112.134:9443
- Check service logs for errors

### Service Won't Start
- Verify .NET Runtime is installed
- Check file permissions in install directory
- Run `Get-EventLog -LogName Application -Source "RdpRelay*" -Newest 10`

### Connection Issues
- Test connectivity: `Test-NetConnection 159.89.112.134 -Port 9443`
- Verify provisioning token is not expired
- Check server logs for authentication errors

## Management Commands

```powershell
# Start service
Start-Service RdpRelayAgent

# Stop service  
Stop-Service RdpRelayAgent

# Restart service
Restart-Service RdpRelayAgent

# Check status
Get-Service RdpRelayAgent

# View logs
Get-Content "C:\Program Files\RdpRelay\Agent\logs\*.log" -Tail 50

# Uninstall
Stop-Service RdpRelayAgent
sc.exe delete RdpRelayAgent
Remove-Item "C:\Program Files\RdpRelay" -Recurse -Force
```

## Support
For issues, check the logs first and verify network connectivity.
